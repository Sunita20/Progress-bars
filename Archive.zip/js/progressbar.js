//<![CDATA[
window.onload=function(){
var ractive = new Ractive({
    el: document.body,
    template: '#bars',
    data: {
        progressbars: [
            { name: 'progress1', value: 0 },
            { name: 'progress2', value: 0 },
			{ name: 'progress3', value: 0 }

            // and so on...
        ],
        amounts: [ +25, +10, -10, -25 ],
        roundOff: function (bars) {
          
            if(bars<=0)
            {
             bars=0;  
            }
			if(bars>=200)
            {
             bars=200;  
            }
            return bars;
     },
    setValue:function(bars)
        { 
            if(bars<=0)
            {
                bars=0;
            }
			if(bars>=200)
            {
             bars=200;  
            }
            return bars;
        }
    },
    adjust: function ( bars ) {
        var selected = this.get( 'selectedProgress' );
        if ( selected == null ) return;        
        var keypath = 'progressbars[' + selected + '].value';   
        if((this.get(keypath))<=0)
        {
            this.set(keypath,0)
        }
		if((this.get(keypath))>=200)
        {
            this.set(keypath,200)
        }
		this.add( keypath, bars);
		var keypath1 = 'progressbars[' + selected + '].progress';        
		this.add( keypath1, bars );
    }
});
}//]]> 
